#include <stdio.h>
#include <stdlib.h>
#define MAX_LINE 1024

// the following code takes in a file by first reading its name
// from the command line and then processes each word (character array
// made of alphabetic characters) in the file and prints each word on a 
// new line

int main(int argc, char** argv){
    if(argc != 2) {
        perror("Usage: ./<executable> <filename>");
        exit(-1);
    }
    FILE* file = fopen(argv[1], "r");
    char buffer[MAX_LINE];
    if(file == NULL) {
        printf("Error opening the file %s", argv[1]);
        exit(-1);
    }
    fgets(buffer, MAX_LINE, file);
    /* TODO: scan the first line of the input file and parse each word and print it out on a separate line
     * ignoring non-characters */
    int i = 0;
    while(buffer[i] != '\0') {
	// process the non-alphabetic characters
        while(!((buffer[i] >= 'a' && buffer[i] <= 'z') || (buffer[i] >= 'A' && buffer[i] <= 'Z'))) {
            i++;
        }
        // process the alphabetic characters until a non-alphabetic character is reached
        while((buffer[i] >= 'a' && buffer[i] <= 'z') || (buffer[i] >= 'A' && buffer[i] <= 'Z')) {
            printf("%c", buffer[i]);
            i++;
        }
        printf("\n");
    }
    fclose(file);

    return 0;
}