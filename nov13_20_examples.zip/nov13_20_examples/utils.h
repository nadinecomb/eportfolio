//
// Created by nadin on 11/12/2024.
//
#ifndef UTILS_H  // Include guard to prevent multiple inclusions
#define UTILS_H

// Function prototypes
void printMessage(const char *message);
int addNumbers(int a, int b);

#endif  // UTILS_H
