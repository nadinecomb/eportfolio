#include <stdio.h>
#include <string.h>
#include <ctype.h>
#define LENGTH 16
// the below program takes in a string of at most 15 characters and prints the
// string in reverse
int main(int argc, char** argv){
    char buffer[LENGTH], temp[LENGTH];
    // scan in the string into the buffer
    scanf("%s", buffer);
    //fscanf(stdin, "%s", buffer);

    // find the string length
    int length = strlen(buffer);

    /*
    for(int i = 0; i < length; i++) {
        temp[i] = buffer[length -1 - i];
    }
    */

    /* // same as above, but as a while loop
    int i = 0;
    while(i < length) {
        temp[i] = buffer[length - 1 - i];
        i++;
    }
    */

    // same as first for loop, but starting from length - 1
    for(int i = length - 1; i >= 0; i--) {
        temp[length - i - 1] = buffer[i];
    }

    // we need to set the last element to a 
    //null char so that we can print the string
    temp[length] = '\0';
    printf("%s\n", temp);
    return 0;
}