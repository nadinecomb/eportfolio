#include <stdio.h>
#include "utils.h"  // Include the header file to use the functions

int main() {
    // Call printMessage function from utils.c
    printMessage("Hello from the main function!");

    // Call addNumbers function from utils.c
    int result = addNumbers(10, 20);
    printf("The result of adding 10 and 20 is: %d\n", result);

    return 0;
}