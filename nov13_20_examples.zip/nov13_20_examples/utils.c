//
// Created by nadin on 11/12/2024.
//

#include <stdio.h>
#include "utils.h"
// Function to print a message
void printMessage(const char *message) {
    printf("%s\n", message);
}

// Function to add two numbers
int addNumbers(int a, int b) {
    return a + b;
}
