#include <stdio.h>
#include <stdlib.h>
#define MAX_LINE 256

int main(int argc, char *argv[]) {
    // Check if there are exactly 3 arguments (program name + 2 filenames)
    if (argc != 3) {
        printf("Usage: %s <file1> <file2>\n", argv[0]);
        return 1; // Exit the program with an error code
    }

    // Open the first file for reading
    FILE *file1 = fopen(argv[1], "r");
    if (file1 == NULL) {
        perror("Error opening file1");
        return 1; // Exit the program with an error code
    } else {
        printf("Successfully opened file: %s\n", argv[1]);
    }

    // Open the second file for reading
    FILE *file2 = fopen(argv[2], "r");
    if (file2 == NULL) {
        perror("Error opening file2");
        fclose(file1); // Close the first file before exiting
        return 1; // Exit the program with an error code
    } else {
        printf("Successfully opened file: %s\n", argv[2]);
    }

    // do something with the files here
    int i = 1;
    char line1[MAX_LINE], line2[MAX_LINE];
    while(fgets(line1, MAX_LINE, file1) && fgets(line2, MAX_LINE, file2)){
        if(atoi(line1) > atoi(line2)){
            printf("green\n");
        }
        else if(atoi(line1) == atoi(line2))
            printf("blue\n");
        else
            printf("pink\n");
    }

    // Close both files before exiting
    fclose(file1);
    fclose(file2);

    return 0; // Successful execution
}
