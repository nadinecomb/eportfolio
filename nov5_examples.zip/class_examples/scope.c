#include <stdio.h>

// Static variable
static int static_var = 10;

// Function prototype
void testFunction();

int main() {
    // Local variable in main function
    int local_var = 20;
    
    printf("In main():\n");
    printf("Static variable: %d\n", static_var);
    
    // Call another function
    testFunction();
    testFunction();
    
    return 0;
}

void testFunction() {
    // Local variable in testFunction
    int local_var_test = 50;

    // Static variable in testFunction
    static int static_test_var = 100;

    printf("\nIn testFunction():\n");
    printf("Static variable outside of function: %d\n", static_var); // static variable accessible here too
    printf("Local variable in testFunction: %d\n", local_var_test); // Local variable, only in testFunction
    printf("Static variable in testFunction: %d\n", static_test_var); // Static variable retains its value between calls

    // Modify variables
    static_test_var += 10;
    local_var_test += 10;
    static_var += 10;
}
