#include <stdio.h>

int main() {
    int a[] = {2, 3, 5, 7, 11, 13, 17, 19}, k, m, x, temp;
    scanf("%d %d %d", &k, &m, &x);
    for (int i = k; i < sizeof(a)/sizeof(a[0]) - 1; i++) {
        a[i] = a[i + 1];
    }
    for (int i = sizeof(a)/sizeof(a[0]); i > m ; i--) {
        a[i] = a[i - 1];
    }

    a[m] = x;

    for (int i = 0; i < sizeof(a)/sizeof(a[0]); i++) {
        printf("%d ", a[i]);
    }

}