#include <stdio.h>

int main() {
    int num = 42;  // Predefined number

    // Print the predefined number
    printf("%d\n", num);

    return 0;
}
