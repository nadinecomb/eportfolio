#include <stdio.h>

int main() {
    int num;

    // Ask the user for input
    printf("Enter a number: ");
    
    // Take input from the user
    scanf("%d", &num);

    // Print the entered number
    printf("You entered: %d\n", num);

    return 0;
}
