#include <stdio.h>

void main(int arr[], int n) {
    int arr[] = {10, 9, 8, 7, 6};
    //let n be the length of arr
    int n = sizeof(arr)/sizeof(arr[0]);

    // go from i = 0 to n - 2 and process each "subarray" (i + 1 to n)
    for (int i = 0; i < n - 1; i++) {
        int min_idx = i;
        // go through each element i+1 to n and find the minimum value's index
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[min_idx]) {
                min_idx = j;
            }
        }
	
	// swap the current element with the minimum index in the array
        int temp = arr[i];
        arr[i] = arr[min_idx];
        arr[min_idx] = temp;
    }
    return 0;
}